<?php
// Heading
$_['heading_title']                 = 'Programme d\'affiliation';

// Text
$_['text_account']                  = 'Compte';
$_['text_login']                    = 'S\'identifier';
$_['text_description']              = '<p>%s le programme d\'affiliation est gratuit et permet aux membres de gagner des revenus en plaçant un lien ou des liens sur leur site Web qui annonce %s ou des produits spécifiques à ce sujet. Toute vente faite aux clients qui ont cliqué sur ces liens gagnera la commission affiliée. Le taux de commission standard est actuellement %s.</p><p>Pour plus d\'informations, visitez notre page de FAQ ou consultez nos conditions d\'affiliation.</p>';
$_['text_new_affiliate']            = 'Nouvel Affilié';
$_['text_register_account']         = '<p>Je ne suis actuellement pas affilié.</p><p>Cliquez sur Continuer ci-dessous pour créer un nouveau compte affilié. Veuillez noter que cette connexion ne relève d\'aucune manière de votre compte client.</p>';
$_['text_returning_affiliate']      = 'Connexion affiliée';
$_['text_i_am_returning_affiliate'] = 'Je suis un affilié retour.';
$_['text_forgotten']                = 'mot de passe oublié';

// Entry
$_['entry_email']                   = 'E-mail de l\'affilié';
$_['entry_password']                = 'Mot de passe';

// Error
$_['error_login']                   = 'Attention: Aucune correspondance pour l\'adresse e-mail et / ou le mot de passe.';
$_['error_attempts']                = 'Attention: Votre compte a dépassé le nombre autorisé de tentatives de connexion. Veuillez réessayer dans 1 heure.';
$_['error_approved']                = 'Attention: Votre compte nécessite une approbation avant de pouvoir vous connecter.';