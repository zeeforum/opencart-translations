<?php
// Text
$_['text_success'] = 'Succès: la session API a démarré avec succès!';

// Error
$_['error_key']    = 'Attention: Clé d\'API incorrecte!';
$_['error_ip']     = 'Attention: Votre adresse IP %s n\'est pas autorisé à accéder à cette API!';