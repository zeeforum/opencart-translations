<?php
// Text
$_['text_success']     = 'Succès: votre devise a été modifiée!';

// Error
$_['error_permission'] = 'Attention: Vous n\'avez pas la permission d\'accéder à l\'API!';
$_['error_currency']   = 'Attention: Le code de devise n\'est pas valide!';