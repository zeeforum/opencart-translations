<?php
// Text
$_['text_success']     = 'Succès: vous avez modifié votre panier!';

// Error
$_['error_permission'] = 'Attention: Vous n\'avez pas l\'autorisation d\'accéder à l\'API!';
$_['error_stock']      = 'Produits marqués avec *** ne sont pas disponibles en quantité désirée ou pas en stock!';
$_['error_minimum']    = 'Montant minimum de la commande pour %s est %s!';
$_['error_store']      = 'Le produit ne peut pas être acheté dans le magasin que vous avez choisi!';
$_['error_required']   = '%s requis!';