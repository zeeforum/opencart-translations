<?php
// Text
$_['text_success']     = 'Succès: votre remise de points de récompense a été appliquée!';

// Error
$_['error_permission'] = 'Attention: Vous n\'avez pas la permission d\'accéder à l\'API!';
$_['error_reward']     = 'Attention: Entrez le montant des points de récompense à utiliser!';
$_['error_points']     = 'Attention: Vous n\'avez pas %s points de récompense!';
$_['error_maximum']    = 'Attention: Le nombre maximum de points pouvant être appliqués est %s!';