<?php
// Text
$_['text_success']     = 'Succès: votre réduction de coupon a été appliquée!';

// Error
$_['error_permission'] = 'Attention: Vous n\'avez pas la permission d\'accéder à l\'API!';
$_['error_coupon']     = 'Attention: Le coupon est invalide, expiré ou atteint sa limite d\'utilisation!';