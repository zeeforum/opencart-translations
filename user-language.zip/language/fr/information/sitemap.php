<?php
// Heading
$_['heading_title']    = 'Plan du site';

// Text
$_['text_special']     = 'Offres spéciales';
$_['text_account']     = 'Mon compte';
$_['text_edit']        = 'Information sur le compte';
$_['text_password']    = 'Mot de passe';
$_['text_address']     = 'Carnet d\'adresses';
$_['text_history']     = 'Historique des commandes';
$_['text_download']    = 'Téléchargements';
$_['text_cart']        = 'Chariot';
$_['text_checkout']    = 'Check-out';
$_['text_search']      = 'Chercher';
$_['text_information'] = 'Information';
$_['text_contact']     = 'Contactez nous';