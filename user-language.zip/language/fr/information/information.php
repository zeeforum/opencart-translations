<?php
// Text
$_['text_error'] = 'Page d\'information introuvable!';