<?php
// Text
$_['text_title']          = 'PayPal Express Checkout';
$_['text_canceled']       = 'Succès: Vous avez bien regroupé ce paiement!';

// Button
$_['button_cancel']       = 'Annuler le paiement récurrent';

// Error
$_['error_not_cancelled'] = 'Erreur: %s';
$_['error_not_found']     = 'Impossible d\'annuler le profil récurrent';