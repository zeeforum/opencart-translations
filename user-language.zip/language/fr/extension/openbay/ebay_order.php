<?php
// Text
$_['text_total_shipping']		= 'livraison';
$_['text_total_discount']		= 'Remise';
$_['text_total_tax']			= 'Impôt';
$_['text_total_sub']			= 'Sous-total';
$_['text_total']				= 'Total';
$_['text_smp_id']				= 'Identificateur de vente du vendeur vendeur: ';
$_['text_buyer']				= 'Identifiant de l\'acheteur: ';