<?php

$_['heading_title'] = 'Cartes de crédit carrées';

$_['text_account'] = 'Compte';
$_['text_back'] = 'Arrière';
$_['text_delete'] = 'Effacer';
$_['text_no_cards'] = 'Il n\'y a aucune carte stockée sur notre base de données.';
$_['text_card_ends_in'] = '%s carte se terminant par &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; %s';
$_['text_warning_card'] = 'Confirmez-vous que vous souhaitez supprimer cette carte? Vous pouvez l\'ajouter à nouveau plus tard dans votre prochaine facturation.';
$_['text_success_card_delete'] = 'Succès! Cette carte a été supprimée.';