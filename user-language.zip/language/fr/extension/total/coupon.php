<?php
// Heading
$_['heading_title'] = 'Utilisez le code de coupon';

// Text
$_['text_coupon']   = 'Coupon (%s)';
$_['text_success']  = 'Succès: votre réduction de coupon a été appliquée!';

// Entry
$_['entry_coupon']  = 'Entrez votre coupon ici';

// Error
$_['error_coupon']  = 'Alerte: Le coupon est invalide, expiré ou atteint sa limite d'utilisation!';
$_['error_empty']   = 'Alerte: Entrez un code de coupon!';