<?php
// Heading
$_['heading_title'] = 'Utiliser des points de récompense (Disponible %s)';

// Text
$_['text_reward']   = 'Points de récompense (%s)';
$_['text_order_id'] = 'numéro de commande: #%s';
$_['text_success']  = 'Succès: votre remise de points de récompense a été appliquée!';

// Entry
$_['entry_reward']  = 'Points à utiliser (Max %s)';

// Error
$_['error_reward']  = 'Alerte: Entrez le montant des points de récompense à utiliser!';
$_['error_points']  = 'Alerte: Vous n\'avez pas %s Points de récompense!';
$_['error_maximum'] = 'Alerte: Le nombre maximum de points pouvant être appliqués est %s!';