<?php
// Text
$_['text_credit']   = 'Crédit de magasin';
$_['text_order_id'] = 'numéro de commande: #%s';