<?php
// Heading
$_['heading_title'] = 'Utiliser un certificat-cadeau';

// Text
$_['text_voucher']  = 'Cadeau certifié (%s)';
$_['text_success']  = 'Succès: votre remise du certificat-cadeau a été appliquée!';

// Entry
$_['entry_voucher'] = 'Entrez votre code de certificat cadeau ici';

// Error
$_['error_voucher'] = 'Alerte: Le certificat-cadeau est non valide ou le solde a été utilisé!';
$_['error_empty']   = 'Alerte: Entrez un code de certificat cadeau!';