<?php
// Heading
$_['heading_title'] = 'En vedette';

// Text
$_['text_tax']      = 'Ex Tax:';