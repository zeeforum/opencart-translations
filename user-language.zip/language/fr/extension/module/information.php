<?php
// Heading
$_['heading_title'] = 'Information';

// Text
$_['text_contact']  = 'Contactez nous';
$_['text_sitemap']  = 'Plan du site';