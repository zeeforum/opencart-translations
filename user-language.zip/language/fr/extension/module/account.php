<?php
// Heading
$_['heading_title']    = 'Compte';

// Text
$_['text_register']    = 'registre';
$_['text_login']       = 'S\'identifier';
$_['text_logout']      = 'Connectez - Out';
$_['text_forgotten']   = 'mot de passe oublié';
$_['text_account']     = 'Mon compte';
$_['text_edit']        = 'Modifier le compte';
$_['text_password']    = 'Mot de passe';
$_['text_address']     = 'Carnet d\'adresses';
$_['text_wishlist']    = 'Liste de souhaits';
$_['text_order']       = 'Historique des commandes';
$_['text_download']    = 'Téléchargements';
$_['text_reward']      = 'Points de récompense';
$_['text_return']      = 'Résultats';
$_['text_transaction'] = 'Transactions';
$_['text_newsletter']  = 'Bulletin';
$_['text_recurring']   = 'Paiements récurrents';