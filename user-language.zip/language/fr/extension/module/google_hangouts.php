<?php
// Heading
$_['heading_title'] = 'Discussion en temps réel';