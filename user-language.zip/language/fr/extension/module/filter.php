<?php
// Heading
$_['heading_title'] = 'Affiner votre recherche';