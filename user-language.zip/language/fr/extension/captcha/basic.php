<?php
// Text
$_['text_captcha']  = 'Captcha';

// Entry
$_['entry_captcha'] = 'Entrez le code dans la case ci-dessous';

// Error
$_['error_captcha'] = 'Le code de vérification ne correspond pas à l\'image!';