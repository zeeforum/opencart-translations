<?php
// Text
$_['text_captcha']  = 'Captcha';

// Entry
$_['entry_captcha'] = 'Veuillez compléter la validation de captcha ci-dessous';

// Error
$_['error_captcha'] = 'La vérification n\'est pas correcte!';