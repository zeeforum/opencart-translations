<?php
// Text
$_['text_items']     = '%s article(s) - %s';
$_['text_empty']     = 'Votre panier est vide!';
$_['text_cart']      = 'Voir le panier';
$_['text_checkout']  = 'Check-out';
$_['text_recurring'] = 'Profil de paiement';