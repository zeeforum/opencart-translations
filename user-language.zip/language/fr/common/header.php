<?php
// Text
$_['text_home']          = 'Accueil';
$_['text_wishlist']      = 'Liste de souhaits (%s)';
$_['text_shopping_cart'] = 'Chariot';
$_['text_category']      = 'Catégories';
$_['text_account']       = 'Mon compte';
$_['text_register']      = 'Registre';
$_['text_login']         = 'S\'identifier';
$_['text_order']         = 'Historique des commandes';
$_['text_transaction']   = 'Transactions';
$_['text_download']      = 'Téléchargements';
$_['text_logout']        = 'Connectez - Out';
$_['text_checkout']      = 'Check-out';
$_['text_search']        = 'Chercher';
$_['text_all']           = 'Montre tout';