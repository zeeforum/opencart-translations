<?php
// Text
$_['text_all'] = 'Montre tout';