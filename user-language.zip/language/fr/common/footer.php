<?php
// Text
$_['text_information']  = 'Information';
$_['text_service']      = 'Service Clients';
$_['text_extra']        = 'Extras';
$_['text_contact']      = 'Contactez nous';
$_['text_return']       = 'Résultats';
$_['text_sitemap']      = 'Plan du site';
$_['text_manufacturer'] = 'Marques';
$_['text_voucher']      = 'Certificats-cadeaux';
$_['text_affiliate']    = 'Filiale';
$_['text_special']      = 'Promotions';
$_['text_account']      = 'Mon compte';
$_['text_order']        = 'Historique des commandes';
$_['text_wishlist']     = 'Liste de souhaits';
$_['text_newsletter']   = 'Bulletin';
$_['text_powered']      = 'Alimenté par <a href="http://www.opencart.com">OpenCart</a><br /> %s &copy; %s';