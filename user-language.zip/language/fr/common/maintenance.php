<?php
// Heading
$_['heading_title']    = 'Entretien';

// Text
$_['text_maintenance'] = 'Entretien';
$_['text_message']     = '<h1 style="text-align:center;">Nous effectuons actuellement une maintenance planifiée. <br/>Nous serons de retour dès que possible. Veuillez revenir rapidement.</h1>';