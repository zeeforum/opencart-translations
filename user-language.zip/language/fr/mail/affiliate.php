<?php
// Text
$_['text_subject']        = '%s - Programme d\'affiliation';
$_['text_welcome']        = 'Merci de vous joindre à %s Programme d\'affiliation!';
$_['text_login']          = 'Votre compte a été créé et vous pouvez vous connecter en utilisant votre adresse e-mail et votre mot de passe en visitant notre site Web ou à l\'adresse URL suivante:';
$_['text_approval']       = 'Votre compte doit être approuvé avant de pouvoir vous connecter. Une fois approuvé, vous pouvez vous connecter en utilisant votre adresse e-mail et votre mot de passe en visitant notre site Web ou à l\'URL suivante:';
$_['text_service']        = 'Lors de la connexion, vous pourrez générer des codes de suivi, suivre les paiements de commissions et modifier vos informations de compte.';
$_['text_thanks']         = 'Merci,';
$_['text_new_affiliate']  = 'Nouvel Affilié';
$_['text_signup']         = 'Une nouvelle affiliée s\'est inscrite:';
$_['text_website']        = 'Site Internet:';
$_['text_customer_group'] = 'Groupe de clients:';
$_['text_firstname']      = 'Prénom:';
$_['text_lastname']       = 'Nom de famille:';
$_['text_company']        = 'Compagnie:';
$_['text_email']          = 'Email:';
$_['text_telephone']      = 'Téléphone:';