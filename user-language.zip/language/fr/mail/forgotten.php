<?php
// Text
$_['text_subject']  = '%s - Requête de remise à zéro';
$_['text_greeting'] = 'Un nouveau mot de passe a été demandé pour le compte client de %s.';
$_['text_change']   = 'Pour réinitialiser votre mot de passe, cliquez sur le lien ci-dessous:';
$_['text_ip']       = 'L\'IP utilisé pour faire cette demande était:';