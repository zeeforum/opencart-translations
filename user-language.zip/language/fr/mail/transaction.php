<?php
// Text
$_['text_subject']  = '%s - Commission d\'affiliation';
$_['text_received'] = 'Toutes nos félicitations! Vous avez reçu un paiement de commission auprès de %s Programme d\'affiliation';
$_['text_amount']   = 'Vous avez reçu:';
$_['text_total']    = 'Votre montant total de la commission est maintenant:';