<?php
// Text
$_['text_subject']      = '%s - Commande %s';
$_['text_received']     = 'Vous avez reçu une commande.';
$_['text_order_id']     = 'numéro de commande:';
$_['text_date_added']   = 'date ajoutée:';
$_['text_order_status'] = 'Statut de la commande:';
$_['text_product']      = 'Des produits';
$_['text_total']        = 'Totaux';
$_['text_comment']      = 'Les commentaires pour votre commande sont:';
