<?php
// Text
$_['text_subject']      = '%s - Mise à jour de la commande %s';
$_['text_order_id']     = 'numéro de commande:';
$_['text_date_added']   = 'date ajoutée:';
$_['text_order_status'] = 'Votre commande a été mise à jour selon le statut suivant:';
$_['text_comment']      = 'Les commentaires pour votre commande sont:';
$_['text_link']         = 'Pour afficher votre commande, cliquez sur le lien ci-dessous:';
$_['text_footer']       = 'Veuillez répondre à cet e-mail si vous avez des questions.';