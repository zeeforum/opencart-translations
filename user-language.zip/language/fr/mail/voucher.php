<?php
// Text
$_['text_subject']  = 'Vous avez reçu un certificat-cadeau de %s';
$_['text_greeting'] = 'Félicitations, vous avez reçu un certificat-cadeau d\'une valeur %s';
$_['text_from']     = 'Ce certificat-cadeau vous a été envoyé par %s';
$_['text_message']  = 'Avec un message disant';
$_['text_redeem']   = 'Pour échanger ce certificat-cadeau, écrivez le code de rachat qui est <b>%s</b> puis cliquez sur le lien ci-dessous et achetez le produit sur lequel vous souhaitez utiliser ce certificat-cadeau. Vous pouvez entrer le code du certificat-cadeau sur la page du panier avant de cliquer sur le bon de paiement.';
$_['text_footer']   = 'Veuillez répondre à cet e-mail si vous avez des questions.';