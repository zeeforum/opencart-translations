<?php
// Heading
$_['heading_title']     = 'Compte Téléchargements';

// Text
$_['text_account']      = 'Compte';
$_['text_downloads']    = 'Téléchargements';
$_['text_empty']        = 'Vous n\'avez effectué aucune commande téléchargeable précédente!';

// Column
$_['column_order_id']   = 'numéro de commande';
$_['column_name']       = 'prénom';
$_['column_size']       = 'Taille';
$_['column_date_added'] = 'date ajoutée';