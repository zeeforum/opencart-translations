<?php
// Heading
$_['heading_title'] = 'Déconnexion du compte';

// Text
$_['text_message']  = '<p>Vous avez déconnecté votre compte. Il est maintenant sûr de quitter l\'ordinateur.</p><p>Votre panier a été enregistré, les éléments à l\'intérieur seront restaurés chaque fois que vous vous connectez à votre compte.</p>';
$_['text_account']  = 'Compte';
$_['text_logout']   = 'Connectez - Out';