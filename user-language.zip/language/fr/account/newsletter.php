<?php
// Heading
$_['heading_title']    = 'Inscription à la Newsletter';

// Text
$_['text_account']     = 'Compte';
$_['text_newsletter']  = 'Bulletin';
$_['text_success']     = 'Succès: votre abonnement à la newsletter a été mis à jour avec succès!';

// Entry
$_['entry_newsletter'] = 'Souscrire';