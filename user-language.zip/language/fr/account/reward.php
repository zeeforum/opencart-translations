<?php
// Heading
$_['heading_title']      = 'Vos points de récompense';

// Column
$_['column_date_added']  = 'date ajoutée';
$_['column_description'] = 'La description';
$_['column_points']      = 'Points';

// Text
$_['text_account']       = 'Compte';
$_['text_reward']        = 'Points de récompense';
$_['text_total']         = 'Votre nombre total de points de récompense est:';
$_['text_empty']         = 'Vous n\'avez pas de points de récompense!';