<?php
// Heading
$_['heading_title'] = 'Latest';

// Text
$_['text_tax']      = 'Ex Tax:';